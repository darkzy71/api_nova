import type { Bioskop, BioskopNow } from './types';
export declare function bioskopNow(): Promise<BioskopNow[]>;
export declare function bioskop(page?: number | string): Promise<Bioskop[]>;
//# sourceMappingURL=bioskop.d.ts.map