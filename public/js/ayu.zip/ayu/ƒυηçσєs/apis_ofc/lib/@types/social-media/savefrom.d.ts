import { Savefrom } from './types';
export default function savefrom(url: string): Promise<Savefrom>;
//# sourceMappingURL=savefrom.d.ts.map