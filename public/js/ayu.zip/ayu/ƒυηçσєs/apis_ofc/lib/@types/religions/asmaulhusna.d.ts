import { AsmaulHusna } from './types';
export declare let asmaulhusnajson: AsmaulHusna[];
export default function asmaulhusna(): Promise<AsmaulHusna>;
//# sourceMappingURL=asmaulhusna.d.ts.map