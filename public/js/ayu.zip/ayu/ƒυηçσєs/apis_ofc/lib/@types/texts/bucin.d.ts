export declare let bucinjson: string[];
export default function bucin(): Promise<string>;
//# sourceMappingURL=bucin.d.ts.map