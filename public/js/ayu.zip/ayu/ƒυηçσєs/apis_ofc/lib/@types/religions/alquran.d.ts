import { AlQuran } from './types';
export declare function alquran(): Promise<AlQuran[]>;
//# sourceMappingURL=alquran.d.ts.map