import type { Kbbi } from './types';
/**
 * p = Partikel: kelas kata yang meliputi kata depan, kata sambung, kata seru, kata sandang, ucapan salam
 *
 * n = Nomina: kata benda
 */
export default function kbbi(words: string): Promise<Kbbi[]>;
//# sourceMappingURL=KBBI.d.ts.map