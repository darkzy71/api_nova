export {};
//# sourceMappingURL=cek-resi.d.ts.map