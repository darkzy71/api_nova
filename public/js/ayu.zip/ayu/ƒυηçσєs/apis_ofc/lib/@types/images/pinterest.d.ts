export default function pinterest(query: string): Promise<string[]>;
//# sourceMappingURL=pinterest.d.ts.map