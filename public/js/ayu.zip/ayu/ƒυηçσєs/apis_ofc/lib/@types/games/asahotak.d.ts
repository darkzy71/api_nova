import { AsahOtak } from './types';
export declare let asahotakjson: AsahOtak[];
export default function asahotak(): Promise<AsahOtak>;
//# sourceMappingURL=asahotak.d.ts.map