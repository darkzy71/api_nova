import asmaulhusna, { asmaulhusnajson } from './asmaulhusna.js';
import jadwalsholat, { listJadwalSholat } from './jadwalsholat.js';
export * from './alquran.js';
export { asmaulhusna, asmaulhusnajson, jadwalsholat, listJadwalSholat };
//# sourceMappingURL=index.d.ts.map