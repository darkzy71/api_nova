import type { CNBCIndonesia } from './types';
export default function cnbindonesia(): Promise<CNBCIndonesia[]>;
//# sourceMappingURL=cnbcindonesia.d.ts.map