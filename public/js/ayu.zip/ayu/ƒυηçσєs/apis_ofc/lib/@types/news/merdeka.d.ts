import type { Merdeka } from './types';
export default function merdeka(): Promise<Merdeka[]>;
//# sourceMappingURL=merdeka.d.ts.map