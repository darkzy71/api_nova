import type { Lyrics } from './types';
export declare function lyrics(query: string): Promise<Lyrics>;
export declare function lyricsv2(query: string): Promise<Lyrics>;
//# sourceMappingURL=lyrics.d.ts.map