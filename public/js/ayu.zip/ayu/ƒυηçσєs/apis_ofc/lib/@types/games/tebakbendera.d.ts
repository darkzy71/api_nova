import { TebakBendera } from './types';
export declare let tebakbenderajson: TebakBendera[];
export default function tebakbendera(): Promise<TebakBendera>;
//# sourceMappingURL=tebakbendera.d.ts.map