import { TwitterDownloader, TwitterDownloaderv2 } from './types';
export declare function twitterdl(url: string): Promise<TwitterDownloader[] | []>;
export declare function twitterdlv2(url: string): Promise<TwitterDownloaderv2[]>;
//# sourceMappingURL=twitter.d.ts.map