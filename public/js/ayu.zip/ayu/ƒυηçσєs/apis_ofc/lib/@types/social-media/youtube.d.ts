import { YoutubeDownloader, YoutubeDownloaderV3 } from './types';
export declare function youtubedl(url: string, server?: string): Promise<YoutubeDownloader>;
export declare function youtubedlv2(url: string): Promise<YoutubeDownloader>;
export declare function youtubedlv3(url: string): Promise<YoutubeDownloaderV3>;
//# sourceMappingURL=youtube.d.ts.map