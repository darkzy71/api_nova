import { CakLontong } from './types';
export declare let caklontongjson: CakLontong[];
export default function caklontong(): Promise<CakLontong>;
//# sourceMappingURL=caklontong.d.ts.map