import type { NameFreeFire } from './types';
export default function nameFreeFire(id: string | number): Promise<NameFreeFire>;
//# sourceMappingURL=idff.d.ts.map