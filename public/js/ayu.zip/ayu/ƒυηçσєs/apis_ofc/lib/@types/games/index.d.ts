import asahotak, { asahotakjson } from './asahotak.js';
import caklontong, { caklontongjson } from './caklontong.js';
import family100, { family100json } from './family100.js';
import siapakahaku, { siapakahakujson } from './siapakahaku.js';
import susunkata, { susunkatajson } from './susunkata.js';
import tebakbendera, { tebakbenderajson } from './tebakbendera.js';
import tebakgambar, { tebakgambarjson } from './tebakgambar.js';
import tebakkabupaten, { tebakkabupatenjson } from './tebakkabupaten.js';
import tebakkata, { tebakkatajson } from './tebakkata.js';
import tebakkimia, { tebakkimiajson } from './tebakkimia.js';
import tebaklirik, { tebaklirikjson } from './tebaklirik.js';
import tebaktebakan, { tebaktebakanjson } from './tebaktebakan.js';
import tekateki, { tekatekijson } from './tekateki.js';
export { tebakgambar, tebakgambarjson, caklontong, caklontongjson, family100, family100json, asahotak, asahotakjson, tebakkata, tebakkatajson, tekateki, tekatekijson, tebakkimia, tebakkimiajson, tebakkabupaten, tebakkabupatenjson, siapakahaku, siapakahakujson, susunkata, susunkatajson, tebakbendera, tebakbenderajson, tebaklirik, tebaklirikjson, tebaktebakan, tebaktebakanjson };
//# sourceMappingURL=index.d.ts.map