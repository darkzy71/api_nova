import { TebakLirik } from './types';
export declare let tebaklirikjson: TebakLirik[];
export default function tebaklirik(): Promise<TebakLirik>;
//# sourceMappingURL=tebaklirik.d.ts.map