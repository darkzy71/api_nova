import { GoogleIt } from './types';
export declare function googleIt(query: string): Promise<GoogleIt>;
//# sourceMappingURL=google-it.d.ts.map