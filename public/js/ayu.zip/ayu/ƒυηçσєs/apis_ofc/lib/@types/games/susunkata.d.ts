import { SusunKata } from './types';
export declare let susunkatajson: SusunKata[];
export default function susunkata(): Promise<SusunKata>;
//# sourceMappingURL=susunkata.d.ts.map