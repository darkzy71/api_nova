import { TebakKimia } from './types';
export declare let tebakkimiajson: TebakKimia[];
export default function tebakkimia(): Promise<TebakKimia>;
//# sourceMappingURL=tebakkimia.d.ts.map