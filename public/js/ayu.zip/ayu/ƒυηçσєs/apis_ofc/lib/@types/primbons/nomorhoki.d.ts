import { NomerHoki } from './types';
export default function nomorhoki(nomer: number | string): Promise<NomerHoki>;
//# sourceMappingURL=nomorhoki.d.ts.map