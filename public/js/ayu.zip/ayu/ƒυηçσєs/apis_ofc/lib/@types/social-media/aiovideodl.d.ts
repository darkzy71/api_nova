import { Aiovideodl } from './types';
export default function aiovideodl(url: string): Promise<Aiovideodl>;
//# sourceMappingURL=aiovideodl.d.ts.map