import { FacebookDownloader, FacebookDownloaderV2, FacebookDownloaderV3 } from './types';
export declare function facebookdl(url: string): Promise<FacebookDownloader>;
export declare function facebookdlv2(url: string): Promise<FacebookDownloaderV2>;
export declare function facebookdlv3(url: string): Promise<FacebookDownloaderV3>;
//# sourceMappingURL=facebook.d.ts.map