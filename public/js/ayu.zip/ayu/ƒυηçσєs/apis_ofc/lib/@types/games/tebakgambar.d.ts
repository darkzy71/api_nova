import { TebakGambar } from './types';
export declare let tebakgambarjson: TebakGambar[];
export default function tebakgambar(): Promise<TebakGambar>;
//# sourceMappingURL=tebakgambar.d.ts.map