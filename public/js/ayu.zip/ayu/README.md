<div align="center">
<img src="https://telegra.ph/file/9c9fbbfb7aeff731ab574.jpg" alt="ayumi" width="300" />

</p>
<h1 align="center">Ayumi Bot</h1>

<h1 align="center">Não esqueça de dar estrelas e seguir :)</h1>

>
>
>
</div>
<p align="center">
  <a href="https://github.com/sayo-api"><img title="Author" src="https://img.shields.io/badge/Author-sayo-api.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a href="https://github.com/sayo-api"><img title="Author" src="https://img.shields.io/badge/Author-sayo-api.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a
  <a href="https://wa.me/5562936180708">MEU CONTATO >//< </a>
</h4>
</p>

## COMO INSTALAR NO TERMUX
```bash
> termux-setup-storage
> pkg update && pkg upgrade
> pkg install git
> pkg install nodejs
> pkg install bash
> pkg install ffmpeg
> pkg install libwebp
> git clone https://github.com/sayo-api/ayumi
> cd ayumi
> npm i -no-bin-links
> sh iniciar.sh
# para o sdcard (arquivo baixado)
> cd /sdcard
> cd ayumi
> npm i -no-bin-links
> sh iniciar.sh
```

# Rodar no heroku

Ayumi v 1.0

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/sayo-api/ayumi)




# Heroku Buildpack

| BuildPack | LINK |
|--------|--------|
| **FFMPEG** |[aqui](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **IMAGEMAGICK** | [aqui](https://github.com/DuckyTeam/heroku-buildpack-imagemagick) |
| **Node.js [cópia]**     | heroku/nodejs|


# AGRADECIMENTOS A
 [`Baileys`](https://github.com/adiwajshing/Baileys)

---------